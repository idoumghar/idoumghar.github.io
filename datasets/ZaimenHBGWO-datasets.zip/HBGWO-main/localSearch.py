import networkx as nx
import networkx.algorithms.components as comp
from networkx.utils import pairwise, not_implemented_for
from itertools import combinations, chain
import Connectivity_repair_SP as sp
import matplotlib.pyplot as plt
import PropagationModel as pm


def get_paths(graph, source, target):
    return list(nx.all_simple_paths(graph, source, target))


def get_path_cost(graph,path):
    print("get path cost")
    cost = 0
    for node in path:
        cost = cost + 1
    print("nb nodes  in path ", cost)
    #return graph.get_edge_data(*path)['weigth']
    return cost


def get_least_cost_path(graph, paths):
    min_cost_path = None
    min_cost = float("inf")
    for path in paths:
        cost = get_path_cost(graph, path)
        if cost < min_cost:
            min_cost = cost
            min_cost_path = path
    return min_cost_path, min_cost


def check_terminals_connected(tree, nb_insetred_terminals, nb_terminals):
    return len(list(comp.connected_components(tree))) == 1 and nb_insetred_terminals == nb_terminals


def search_least_cost_paths(graph, terminal1, terminal2):
    print((terminal1, terminal2))
    paths = get_paths(graph, terminal1, terminal2)
    least_cost_path, least_cost = get_least_cost_path(graph, paths)
    print(least_cost_path)
    path = dict()
    path['cost'] = least_cost
    path['path'] = least_cost_path
    path['src'] = terminal1
    path['dest'] = terminal2
    print
    "Path" + str(path['path'])
    print((terminal1, terminal2))
    return path


def steiner_tree(G, terminal_nodes, M):
    H = M.subgraph(terminal_nodes)
    mst_edges = nx.minimum_spanning_edges(H, weight='distance', data=True)
    # Create an iterator over each edge in each shortest path; repeats are okay
    edges = chain.from_iterable(pairwise(d['path']) for u, v, d in mst_edges)
    T = G.edge_subgraph(edges)

    return T

"""
def local_search_with_idea_of_augmented_graph(wsn_graph, metric, wolf):
    print("nodes of wsn graph")
    print(list(wsn_graph.nodes))
    terminals=[]
    sub_metric = metric.subgraph(list(set(wsn_graph.nodes)))
    print("nodes of sub metric ", list(sub_metric.nodes))
    augmented_sub_graph = nx.Graph(sub_metric)
    print("edges of augmented sub graph")
    #for e in augmented_sub_graph.edges:
    #    print(augmented_sub_graph.get_edge_data(*e))
    #augmented_sub_graph.add_edges_from(sub_metric.edges)
    print("nb nodes before augmenting ", len(augmented_sub_graph.nodes))
    t=0
    for pair in wolf.targets_and_its_covering_sensors:
        print("add a terminal")

        terminals.append((pair['target']+10000))
        print(terminals)
        for s in pair['sensors']:
            #augmented_sub_graph.add_edge((pair['target']+10000), s, weight=1, path=[(pair['target']+10000), s])
            augmented_sub_graph.add_edge((pair['target'] + 10000), s)

    """

"""
    print("terminals after the for loop ", terminals)
    
    if len(terminals)>0:
        print("the terminal is ", terminals[0])
        print("nb nodes after augmenting ", len(augmented_sub_graph.nodes))
        print("last edge inserted ", end="  ")
        edges = augmented_sub_graph.edges(terminals[0])
        for e in edges:
            print("weight of edge")
            print(augmented_sub_graph.get_edge_data(*e)['weight'])
            if e in augmented_sub_graph.edges:
                print("the edge is inside the list of edges")
            else:
                print("the edge is outside the list of edges")
    """
"""
    #for e in augmented_sub_graph.edges:
    #    print(augmented_sub_graph.get_edge_data(*e))
    #print("nodes of augmented sub graph ", list(augmented_sub_graph.nodes))
    H=nx.Graph()
    for i in range(len(wolf.targets_and_its_covering_sensors)-1):
        for j in range(i+1, len(wolf.targets_and_its_covering_sensors)):
            source = wolf.targets_and_its_covering_sensors[i]['target']+10000
            destination = wolf.targets_and_its_covering_sensors[j]['target']+10000
            print("source", source)
            print("destination", destination)
            least_cost_path = nx.shortest_path(augmented_sub_graph, source=(source),
                                               target=(destination), weight='weight')
            print("short path")
            print(least_cost_path)
            if len(least_cost_path) >1:
                for i in range(len(least_cost_path)-1):
                    print(least_cost_path[i])
                    if augmented_sub_graph.has_edge(least_cost_path[i], least_cost_path[i + 1]):
                        print("edge", least_cost_path[i], least_cost_path[i + 1], " is in augmented and data is ")
                        print(augmented_sub_graph.get_edge_data(*(least_cost_path[i], least_cost_path[i + 1])))
                    else:
                        print("augmented sub graph does not have the edge ", least_cost_path[i], least_cost_path[i + 1])

                print(augmented_sub_graph.get_edge_data(*least_cost_path))

            nx.add_path(H, least_cost_path)
    mst = nx.minimum_spanning_tree(H, weight='distance')

    #H = augmented_sub_graph.subgraph(terminals)
    print("list edges of H ", list(H.edges))
    print("nodes of H ", list(H.nodes))
    print("nodes of mst", list(mst.nodes))
    print("list edges of mst ", list(mst.edges))
    T = nx.Graph()
    for e in mst.edges:
        if e[0] not in terminals and e[1] not in terminals:
            least_cost_path = nx.shortest_path(wsn_graph, source=e[0], target=e[1])
            nx.add_path(T, least_cost_path)
    print("nodes of T ", list(T.nodes))
    nodes_to_keep= list(set(T.nodes()))
    print("nodes to keep", end="  ")
    print(nodes_to_keep)
    print("all nodes ", end="  ")
    print(list(wsn_graph.nodes))
    print("nodes to remove ", end="  ")
    print(list(set(wsn_graph.nodes) - set(nodes_to_keep)))
    return list(set(wsn_graph.nodes) - set(nodes_to_keep))     
"""



def local_search(wsn_graph, sub_metric, terminals):

    H = sub_metric.subgraph(terminals)
    mst_edges = nx.minimum_spanning_edges(H, weight='distance', data=True)
    # Create an iterator over each edge in each shortest path; repeats are okay
    edges = chain.from_iterable(pairwise(d['path']) for u, v, d in mst_edges)
    T = wsn_graph.edge_subgraph(edges)
    nodes_to_keep = list(set(T.nodes))
    return list(set(wsn_graph.nodes) - set(nodes_to_keep))



"""
def local_search(wsn_graph, metric, terminals):
    sub_metric = metric.subgraph(list(set(wsn_graph.nodes)))
    H = sub_metric.subgraph(terminals)
    mst_edges = nx.minimum_spanning_edges(H, weight='distance', data=True)
    # Create an iterator over each edge in each shortest path; repeats are okay
    edges = chain.from_iterable(pairwise(d['path']) for u, v, d in mst_edges)
    T = wsn_graph.edge_subgraph(edges)
    #T_nodes = list(set(T.nodes) - set(targets))
    nodes_to_keep= list(set(T.nodes))
    print("nodes to keep", end="  ")
    print(nodes_to_keep)
    print("all nodes ", end="  ")
    print(list(wsn_graph.nodes))
    print("nodes to remove ", end="  ")
    print(list(set(wsn_graph.nodes) - set(nodes_to_keep)))
    return list(set(wsn_graph.nodes) - set(nodes_to_keep))
"""

def local_search_actual(wsn_graph, metric, terminals):
    sub_metric = metric.subgraph(list(set(wsn_graph.nodes))).copy()
    H = sub_metric.subgraph(list(set(terminals))).copy()
    mst_edges = nx.minimum_spanning_edges(H, weight='distance', data=True)
    edges = chain.from_iterable(pairwise(d['path']) for u, v, d in mst_edges)
    print("len edges", len(list(edges)))
    for i in range(len(list(edges))):
        print("entrered")
        print(*list(edges)[i])
    for e in list(edges):
        print(*e)
        if wsn_graph.has_edge(*e):
            print(True)
        else:
            print(False)
    T = (wsn_graph.edge_subgraph(edges)).copy()
    print("nodes of T ", list(T.nodes))

    nodes_to_keep = list(set(T.nodes()))
    print("nodes to keep", end="  ")
    print(nodes_to_keep)
    print("all nodes ", end="  ")
    print(list(wsn_graph.nodes))
    print("nodes to remove ", end="  ")
    print(list(set(wsn_graph.nodes) - set(nodes_to_keep)))
    return list(set(wsn_graph.nodes) - set(nodes_to_keep))