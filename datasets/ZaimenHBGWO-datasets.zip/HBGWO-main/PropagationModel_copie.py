from shapely.geometry import LineString
from scipy.spatial import distance
import math


def obstacle_to_line(obstacle):
    return LineString([(obstacle.x0, obstacle.y0), (obstacle.x1, obstacle.y1)])


def Elfes_model(xs, ys, xT, yT, Rs, Ru):
    x=distance.euclidean([xs, ys], [xT, yT])
    if x<= Ru:

        return True
    else:
        if x> Ru and x<= Rs-Ru and math.exp(x-Ru)* 0.01 <0.5:
            return True
        else:
            return False


def MWM(xs1, ys1, xs2, ys2, obstacles,threshold, rc):
    Pt=3
    d= distance.euclidean([xs1, ys1], [xs2, ys2])
    f= 2400000000
    L=1
    PLd0=7.5
    n = 2.8
    interference_1= -6 #for plasterboard
    interference_2 = -25 # for concrete
    interference_3=-10 #for brick
    # Calculate the loss due to walls
    L_mw = 0
    for obstacle in obstacles:
        if obstacle_to_line(obstacle).intersects(LineString([(xs1, ys1), (xs2, ys2)])):
            if obstacle.type == 1:
                L_mw = L_mw + interference_1
            else:
                L_mw = L_mw + interference_2


    # Calculate the signal strength at the receiver
    PL = Pt- PLd0- 10 * n * math.log10(d+0.01) + L_mw

    return PL>=threshold and d<=rc