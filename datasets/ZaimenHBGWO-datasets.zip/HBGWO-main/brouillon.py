import random

l=random.sample(range(0, 254), 140)
print(l)
"""
fichier="resultats"+str(5)

def save_results(fichier, result):
    with open(fichier, 'a') as f:
        # Write a new line to the file
        f.write(result)
        f.write('\n')

for i in range(10):
    save_results(fichier, str(i))
"""